package com.greenCarWash.Customer.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Customer.model.Profile;
import com.greenCarWash.Customer.repository.ProfileRepo;

@RestController
@RequestMapping("/api/v1")
public class ProfileController {
	
	@Autowired
	private ProfileRepo repository;
	
	@PostMapping("/profile")
	public String saveBook(@RequestBody Profile profile) {
		repository.save(profile);
		return profile.getFirstName() + " your Profile is saved";
	}
	@GetMapping("/profile")
	public List<Profile> getBooks(){
		return repository.findAll();
	}
	@GetMapping("/profile/{id}")
	public ResponseEntity<Profile> getProfileById(@PathVariable int id){
		Profile profile= repository.findById(id).orElseThrow();
		return ResponseEntity.ok(profile);
	}
	@PutMapping("/profile/{id}")
	public ResponseEntity<Profile> updateCar(@PathVariable int id, @RequestBody Profile profile){
		Profile profilee= repository.findById(id).orElseThrow();
		
		profilee.setId(profile.getId());
		profilee.setFirstName(profile.getFirstName());
		profilee.setLastName(profile.getLastName());
		profilee.setPhone(profile.getPhone());
		profilee.setAddress(profile.getAddress());
		
		Profile updatedProfile= repository.save(profilee);
		return ResponseEntity.ok(updatedProfile);
	}
}
