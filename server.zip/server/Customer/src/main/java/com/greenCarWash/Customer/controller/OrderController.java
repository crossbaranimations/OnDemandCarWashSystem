package com.greenCarWash.Customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Customer.model.Order;
import com.greenCarWash.Customer.repository.OrderRepo;

@RestController
@RequestMapping("/api/v1/")
public class OrderController {
	
	@Autowired
	private OrderRepo repository;
	
	@PostMapping("/order")
	public int saveBook(@RequestBody Order order) {
		repository.save(order);
		return order.getId();
	}
	
	@GetMapping("/order")
	public List<Order> getBooks(){
		return repository.findAll();
	}
	
	@GetMapping("/order/{id}")
	public ResponseEntity<Order> getOrderByName(@PathVariable int id){
		Order order= repository.findById(id).orElseThrow();
		return ResponseEntity.ok(order);
	}
	@PutMapping("/order/{id}")
	public ResponseEntity<Order> updateOrder(@PathVariable int id, @RequestBody Order order){
		Order ordere= repository.findById(id).orElseThrow();
		
		ordere.setEmail(order.getEmail());
		ordere.setCarType(order.getCarType());
		ordere.setCarName(order.getCarName());
		ordere.setVehicleNo(order.getVehicleNo());
		ordere.setService(order.getService());
		ordere.setAddOns(order.getAddOns());
		ordere.setCost(order.getCost());
		ordere.setAsWasher(order.getAsWasher());
		ordere.setOrderStatus(order.getOrderStatus());
		
		Order updatedOrder= repository.save(ordere);
		return ResponseEntity.ok(updatedOrder);
		
	}
}
