package com.GreenCarWash.Washer.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Order")
public class Order {
	
	@Id
	private int id;
	private String email;
	private String carType;
	private String carName;
	private String vehicleNo;
	private String service;
	private String addOns;
	private int cost;
	private String asWasher;
	private String orderStatus;
	
	public Order() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getAddOns() {
		return addOns;
	}

	public void setAddOns(String addOns) {
		this.addOns = addOns;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getAsWasher() {
		return asWasher;
	}

	public void setAsWasher(String asWasher) {
		this.asWasher = asWasher;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", email=" + email + ", carType=" + carType + ", carName=" + carName + ", vehicleNo="
				+ vehicleNo + ", service=" + service + ", addOns=" + addOns + ", cost=" + cost + ", asWasher="
				+ asWasher + ", orderStatus=" + orderStatus + "]";
	}


}
