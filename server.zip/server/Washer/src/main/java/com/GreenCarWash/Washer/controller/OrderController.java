package com.GreenCarWash.Washer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.GreenCarWash.Washer.model.Order;


@RestController
@RequestMapping("/api/v1/")
public class OrderController {
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping
	public Order[] getOrder() {
		ResponseEntity<Order[]> response= restTemplate.getForEntity("http://localhost:8090/Customer/order", Order[].class);
		Order[] order= response.getBody();
		return order.clone();
	}
	
	
}
