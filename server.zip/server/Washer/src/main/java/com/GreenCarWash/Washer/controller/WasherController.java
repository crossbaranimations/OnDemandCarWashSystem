package com.GreenCarWash.Washer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.GreenCarWash.Washer.model.Washer;

@RestController
@RequestMapping("/api/v1/")
public class WasherController {
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/washer")
	public Washer[] getWasher() {
		ResponseEntity<Washer[]> response= restTemplate.getForEntity("http://localhost:8090/Admin/washer", Washer[].class);
		Washer[] washer= response.getBody();
		return washer.clone();
	}
}
