package com.greenCarWash.Admin.controller;

public class PromoCodeController {

}
