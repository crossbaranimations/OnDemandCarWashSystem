package com.greenCarWash.Admin.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="Washer")
public class Washer {
	@Id
	private int id;
	private String washerName;
	private int washes;
	private String address;
	private long phone;
	private boolean active;
	
	public Washer() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWasherName() {
		return washerName;
	}

	public void setWasherName(String washerName) {
		this.washerName = washerName;
	}

	public int getWashes() {
		return washes;
	}

	public void setWashes(int washes) {
		this.washes = washes;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Washer [id=" + id + ", washerName=" + washerName + ", washes=" + washes + ", address=" + address
				+ ", phone=" + phone + ", active=" + active + "]";
	}
	
}
