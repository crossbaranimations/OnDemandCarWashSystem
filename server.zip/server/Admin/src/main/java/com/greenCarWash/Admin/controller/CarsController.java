package com.greenCarWash.Admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Admin.models.Cars;
import com.greenCarWash.Admin.repository.CarsRepo;

@RestController
@RequestMapping("/api/v1/")
public class CarsController {
	
	@Autowired
	private CarsRepo repository;
	
	@PostMapping("/car")
	public String saveBook(@RequestBody Cars cars){
		repository.save(cars);
		return "Car saved with id: "+ cars.getId();
	}
	@GetMapping("/car/{id}")
	public ResponseEntity<Cars> getCarById(@PathVariable int id){
		Cars car = repository.findById(id).orElseThrow();
		return ResponseEntity.ok(car);
	}
	@GetMapping("/car")
	public List<Cars> getBooks(){
		return repository.findAll();
	}
	@PutMapping("/cars/{id}")
	public ResponseEntity<Cars> updateCar(@PathVariable int id, @RequestBody Cars cars){
		Cars car= repository.findById(id).orElseThrow();
		
		car.setId(cars.getId());
		car.setBrand(cars.getBrand());
		car.setType(cars.getType());
		car.setModel(cars.getModel());
		car.setActive(cars.isActive());
		
		Cars updatedCar= repository.save(car);
		return ResponseEntity.ok(updatedCar);
	}
	@DeleteMapping("/car/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteCar(@PathVariable int id){
		Cars car= repository.findById(id).orElseThrow();
		
		repository.delete(car);
		Map<String,Boolean> response= new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}
