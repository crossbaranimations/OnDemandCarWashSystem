package com.greenCarWash.Admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Admin.models.Washer;
import com.greenCarWash.Admin.repository.WasherRepo;

@RestController
@RequestMapping("/api/v1")
public class WasherController {

	@Autowired
	private WasherRepo repository;
	
	@PostMapping("/washer")
	public String saveBook(@RequestBody Washer washer) {
		repository.save(washer);
		return "Washer added with id: "+ washer.getWasherName();
	}
	
	@GetMapping("/washer/{id}")
	public ResponseEntity<Washer> getWasherById(@PathVariable int id){
		Washer washer= repository.findById(id).orElseThrow();
		return ResponseEntity.ok(washer);
	}
	
	@GetMapping("/washer")
	public List<Washer> getBooks(){
		return repository.findAll();
	}
	
	@PutMapping("/washer/{id}")
	public ResponseEntity<Washer> updateWasher(@PathVariable int id, @RequestBody Washer washer){
		Washer washerr= repository.findById(id).orElseThrow();
		
		washerr.setId(washer.getId());
		washerr.setWasherName(washer.getWasherName());
		washerr.setAddress(washer.getAddress());
		washerr.setPhone(washer.getPhone());
		washerr.setWashes(washer.getWashes());
		washerr.setActive(washer.isActive());
		
		Washer updatedWasher= repository.save(washerr);
		return ResponseEntity.ok(updatedWasher);
	}
}
