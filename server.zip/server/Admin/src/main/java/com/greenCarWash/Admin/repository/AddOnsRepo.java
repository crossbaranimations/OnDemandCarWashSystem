package com.greenCarWash.Admin.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.greenCarWash.Admin.models.AddOns;
@Repository
public interface AddOnsRepo extends MongoRepository<AddOns, Integer>{

}
