package com.greenCarWash.Admin.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.greenCarWash.Admin.models.PromoCode;

@Repository
public interface PromoCodeRepo extends MongoRepository<PromoCode, Integer> {

}
