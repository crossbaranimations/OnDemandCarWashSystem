package com.greenCarWash.Admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Admin.models.AddOns;
import com.greenCarWash.Admin.repository.AddOnsRepo;

@RestController
@RequestMapping("/api/v1/")
public class AddOnsController {

		@Autowired
		private AddOnsRepo repository;
		
		@PostMapping("/addOn")
		public String saveBook(@RequestBody AddOns addOns) {
			repository.save(addOns);
			return "AddOns saved with id: "+ addOns.getId();
		}
		
		@GetMapping("/addOn/{id}")
		public ResponseEntity<AddOns> getAddonById(@PathVariable int id){
			AddOns addon= repository.findById(id).orElseThrow();
			return ResponseEntity.ok(addon);
		}
		
		@GetMapping("/addOn")
		public List<AddOns> getBooks(){
			return repository.findAll();
		}
		
		@PutMapping("/addOn/{id}")
		public ResponseEntity<AddOns> updateAddOn(@PathVariable int id, @RequestBody AddOns addOn){
			AddOns addon= repository.findById(id).orElseThrow();
			
			addon.setId(addOn.getId());
			addon.setService(addOn.getService());
			addon.setDescription(addOn.getDescription());
			addon.setCost(addOn.getCost());
			addon.setStatus(addOn.isStatus());
			
			AddOns updatedAddOn = repository.save(addon);
			return ResponseEntity.ok(updatedAddOn);
			
		}
		
		@DeleteMapping("/addOn/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteAddOn(@PathVariable int id){
			AddOns addon= repository.findById(id).orElseThrow();
			
			repository.delete(addon);
			Map<String,Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}		
}
