package com.greenCarWash.Admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.greenCarWash.Admin.models.Services;
import com.greenCarWash.Admin.repository.ServicesRepo;

@RestController
@RequestMapping("/api/v1/")
public class ServicesController {
	
	@Autowired 
	ServicesRepo repository;
	
	@PostMapping("/service")
	public String saveBook(@RequestBody Services services) {
		repository.save(services);
		return "Service add with id: "+services.getId();
	}
	@GetMapping("/service/{id}")
	public ResponseEntity<Services> getServiceById(@PathVariable int id){
		Services service = repository.findById(id).orElseThrow();
		return ResponseEntity.ok(service);
	}
	
	@GetMapping("/service")
	public List<Services> getBooks(){
		return repository.findAll();
	}
	@PutMapping("/service/{id}")
	public ResponseEntity<Services> updateService(@PathVariable int id, @RequestBody Services services){
		Services service = repository.findById(id).orElseThrow();
		
		service.setId(services.getId());
		service.setService(services.getService());
		service.setDescription(services.getDescription());
		service.setCost(services.getCost());
		service.setStatus(services.isStatus());
		
		Services updatedService = repository.save(service);
		return ResponseEntity.ok(updatedService);
	}
	@DeleteMapping("/service/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteService(@PathVariable int id){
		Services service = repository.findById(id).orElseThrow();
		
		repository.delete(service);
		Map<String,Boolean> response= new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}
