package com.greenCarWash.Admin.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

//Model for promocodes
@Document(collection="Promos")
public class PromoCode {
	
	@Id
	private int id;
	private String code;
	private String codeDesc;
	private boolean status;
	
	public PromoCode() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCodeDesc() {
		return codeDesc;
	}

	public void setCodeDesc(String codeDesc) {
		this.codeDesc = codeDesc;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "PromoCode [id=" + id + ", code=" + code + ", codeDesc=" + codeDesc + ", status=" + status + "]";
	}
	
}
