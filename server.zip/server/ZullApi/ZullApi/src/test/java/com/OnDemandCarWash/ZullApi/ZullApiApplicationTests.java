package com.OnDemandCarWash.ZullApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZullApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
